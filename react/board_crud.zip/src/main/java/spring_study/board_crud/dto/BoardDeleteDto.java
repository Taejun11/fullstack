package spring_study.board_crud.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BoardDeleteDto {
    private Long id;
}
